# resnet-flask-webapp
this is flask webapp deploying resnet50 model

tutorial: https://youtu.be/i8Dw9msoDWQ
